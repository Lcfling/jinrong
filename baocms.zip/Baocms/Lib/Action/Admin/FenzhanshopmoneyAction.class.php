<?php


class FenzhanshopmoneyAction extends CommonAction{
	
	  public function _initialize() {
		$this->citys = D('City')->fetchAll();
     }

    
    public  function index(){
		
	   $city_id = (int) $this->_param('city_id');
       $this->assign('city_id', $city_id);
		
       $Shopmoney = D('Shopmoney');
       import('ORG.Util.Page');// 导入分页类
       $map = array('city_id'=>$city_id);
        if(($bg_date = $this->_param('bg_date',  'htmlspecialchars') )&& ($end_date=$this->_param('end_date','htmlspecialchars'))){
           $bg_time = strtotime($bg_date);
           $end_time = strtotime($end_date) + 86400;
           $map['create_time'] = array(array('ELT',$end_time),array('EGT',$bg_time));
           $this->assign('bg_date',$bg_date);
           $this->assign('end_date',$end_date);
       }else{
           if($bg_date = $this->_param('bg_date',  'htmlspecialchars')){
               $bg_time = strtotime($bg_date);
               $this->assign('bg_date',$bg_date);
               $map['create_time'] = array('EGT',$bg_time);
           }
           if($end_date = $this->_param('end_date',  'htmlspecialchars')){
               $end_time = strtotime($end_date)+ 86400;
               $this->assign('end_date',$end_date);
               $map['create_time'] = array('ELT',$end_time);
           }
       }

       if($keyword = $this->_param('keyword','htmlspecialchars')){
           $map['order_id'] = array('LIKE', '%'.$keyword.'%');
           $this->assign('keyword',$keyword);
       } 
       if($shop_id = (int)$this->_param('shop_id')){
            $map['shop_id'] = $shop_id;
            $shop = D('Shop')->find($shop_id);
            $this->assign('shop_name',$shop['shop_name']);
            $this->assign('shop_id',$shop_id);
        }
       
       
       $count      = $Shopmoney->where($map)->count();// 查询满足要求的总记录数 
       $Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
       $show       = $Page->show();// 分页显示输出
       $list = $Shopmoney->where($map)->order(array('money_id'=>'desc'))->limit($Page->firstRow.','.$Page->listRows)->select();
       $shop_ids = array();
       foreach($list as  $val){
           $shop_ids[$val['shop_id']] = $val['shop_id'];
       }
       $this->assign('shops',D('Shop')->itemsByIds($shop_ids));
       $this->assign('list',$list);// 赋值数据集
       $this->assign('page',$show);// 赋值分页输出
       $this->display(); // 输出模板
    }
    
    
    public function tjmonth(){
		
	   $city_id = (int) $this->_param('city_id');
       $this->assign('city_id', $city_id);
	   
	   
       $Shopmoney = D('Shopmoney');
       import('ORG.Util.Page');// 导入分页类

        if($month = $this->_param('month',  'htmlspecialchars')){
            $this->assign('month',$month);
        }
        if($shop_id = (int)$this->_param('shop_id')){
            $map['shop_id'] = $shop_id;
            $shop = D('Shop')->find($shop_id);
            $this->assign('shop_name',$shop['shop_name']);
            $this->assign('shop_id',$shop_id);
        }
        $count      = $Shopmoney->tjmonthCount($month,$shop_id);// 查询满足要求的总记录数 
        $Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $Page->show();// 分页显示输出
        $list = $Shopmoney->tjmonth($month,$shop_id,$Page->firstRow,$Page->listRows);
        $shop_ids = array();
        foreach($list as  $val){
            $shop_ids[$val['shop_id']] = $val['shop_id'];
        }
        $this->assign('shops',D('Shop')->itemsByIds($shop_ids));
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
    }
    
    public function tjyear(){
		
	   $city_id = (int) $this->_param('city_id');
       $this->assign('city_id', $city_id);
	   
       $Shopmoney = D('Shopmoney');
	   $map = array('city_id'=>$city_id);
       import('ORG.Util.Page');// 导入分页类
        if($year = $this->_param('year',  'htmlspecialchars')){
            $this->assign('year',$year);
        }
        if($shop_id = (int)$this->_param('shop_id')){
            $map['shop_id'] = $shop_id;
            $shop = D('Shop')->find($shop_id);
            $this->assign('shop_name',$shop['shop_name']);
            $this->assign('shop_id',$shop_id);
        }
        $count      = $Shopmoney->tjyearCount($year,$shop_id);// 查询满足要求的总记录数 
        $Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $Page->show();// 分页显示输出
        $list = $Shopmoney->tjyear($year,$shop_id,$Page->firstRow,$Page->listRows);
        $shop_ids = array();
        foreach($list as  $val){
            $shop_ids[$val['shop_id']] = $val['shop_id'];
        }
        $this->assign('shops',D('Shop')->itemsByIds($shop_ids));
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
    }
    
    public function tjday(){
		
	   $city_id = (int) $this->_param('city_id');
       $this->assign('city_id', $city_id);
	   
       $Shopmoney = D('Shopmoney');
       import('ORG.Util.Page');// 导入分页类
		
		
        if($day = $this->_param('day',  'htmlspecialchars')){
            $this->assign('day',$day);
        }
        if($shop_id = (int)$this->_param('shop_id')){
            $map['shop_id'] = $shop_id;
            $shop = D('Shop')->find($shop_id);
            $this->assign('shop_name',$shop['shop_name']);
            $this->assign('shop_id',$shop_id);
        }
        $count      = $Shopmoney->tjdayCount($day,$shop_id);// 查询满足要求的总记录数 
        $Page       = new Page($count,15);// 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $Page->show();// 分页显示输出
        $list = $Shopmoney->tjday($day,$shop_id,$city_id,$Page->firstRow,$Page->listRows);
		
	
		
		
        $shop_ids = array();
        foreach($list as  $val){
            $shop_ids[$val['shop_id']] = $val['shop_id'];
        }
        $this->assign('shops',D('Shop')->itemsByIds($shop_ids));
        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
        
    }
    



    
   
}
